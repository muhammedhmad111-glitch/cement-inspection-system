import {
  collection,
  getDocs,
  doc,
  setDoc,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  serverTimestamp,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../firebase';
import {
  Equipment,
  InspectionPlan,
  InspectionPhase,
  EquipmentPart,
  ChecklistItem,
  InspectionActivity,
  InspectionTaskInstance,
  ImportSummary,
} from '../types/inspection';
import { ParsedWorkbook, normalizeFrequencyUnit, frequencyTypeLabel, parseFrequencyLabel, normalizeOperatingCondition, unitToMs } from './inspectionImport';

const COLLECTIONS = {
  equipment: 'inspection_equipment',
  plans: 'inspection_plans',
  phases: 'inspection_phases',
  parts: 'inspection_parts',
  checklist: 'inspection_checklist_items',
  activities: 'inspection_activities',
  instances: 'inspection_task_instances',
};

function snapToArray<T>(snap: any): T[] {
  const out: T[] = [];
  snap.forEach((d: any) => out.push({ ...(d.data() as T), id: d.id }));
  return out;
}

async function listAll<T>(collectionName: string): Promise<T[]> {
  try {
    const snap = await getDocs(collection(db, collectionName));
    return snapToArray<T>(snap);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, collectionName);
    return [];
  }
}

export const getEquipment = () => listAll<Equipment>(COLLECTIONS.equipment);
export const getPlans = () => listAll<InspectionPlan>(COLLECTIONS.plans);
export const getPhases = () => listAll<InspectionPhase>(COLLECTIONS.phases);
export const getParts = () => listAll<EquipmentPart>(COLLECTIONS.parts);
export const getChecklistItems = () => listAll<ChecklistItem>(COLLECTIONS.checklist);
export const getActivities = () => listAll<InspectionActivity>(COLLECTIONS.activities);
export const getTaskInstances = () => listAll<InspectionTaskInstance>(COLLECTIONS.instances);

export const getPartsByPlan = async (planId: string) => {
  const snap = await getDocs(query(collection(db, COLLECTIONS.parts), where('planId', '==', planId)));
  return snapToArray<EquipmentPart>(snap);
};

export const getChecklistByPart = async (equipmentPartId: string) => {
  const snap = await getDocs(query(collection(db, COLLECTIONS.checklist), where('equipmentPartId', '==', equipmentPartId)));
  return snapToArray<ChecklistItem>(snap);
};

export const updateTaskInstance = async (id: string, data: Partial<InspectionTaskInstance>) => {
  try {
    await updateDoc(doc(db, COLLECTIONS.instances, id), { ...data });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${COLLECTIONS.instances}/${id}`);
  }
};

export const deleteTaskInstance = async (id: string) => {
  try {
    await deleteDoc(doc(db, COLLECTIONS.instances, id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `${COLLECTIONS.instances}/${id}`);
  }
};

// --- Import orchestration -------------------------------------------------

export async function importWorkbook(parsed: ParsedWorkbook): Promise<ImportSummary> {
  const summary: ImportSummary = {
    equipmentCreated: 0,
    plansCreated: 0,
    phasesCreated: 0,
    partsCreated: 0,
    checklistItemsCreated: 0,
    activitiesCreated: 0,
    warnings: [],
  };

  // 1. Equipment — one per unique (equipment_name, equipment_family, source_folder)
  const equipmentKeyToId = new Map<string, string>();
  for (const plan of parsed.plans) {
    const key = `${plan.equipment_name}__${plan.equipment_family || ''}__${plan.source_folder || ''}`;
    if (equipmentKeyToId.has(key)) continue;
    const ref = await addDoc(collection(db, COLLECTIONS.equipment), {
      equipmentName: plan.equipment_name,
      equipmentFamily: plan.equipment_family || '',
      sourceFolder: plan.source_folder || '',
      createdAt: serverTimestamp(),
    });
    equipmentKeyToId.set(key, ref.id);
    summary.equipmentCreated++;
  }

  // 2. Inspection Plans — keyed by source plan_id
  const planIdMap = new Map<string, string>();
  for (const plan of parsed.plans) {
    const equipKey = `${plan.equipment_name}__${plan.equipment_family || ''}__${plan.source_folder || ''}`;
    const equipmentId = equipmentKeyToId.get(equipKey);
    if (!equipmentId) {
      summary.warnings.push(`Plan ${plan.plan_id}: could not resolve equipment`);
      continue;
    }

    let frequencyValue = plan.frequency_value;
    let frequencyUnit = normalizeFrequencyUnit(plan.frequency_unit);
    if (!frequencyValue) {
      const parsedLabel = parseFrequencyLabel(plan.frequency_label);
      if (parsedLabel) {
        frequencyValue = parsedLabel.value;
        frequencyUnit = parsedLabel.unit;
      } else {
        frequencyValue = 1;
        summary.warnings.push(`Plan ${plan.plan_id}: missing frequency, defaulted to monthly`);
      }
    }

    const ref = await addDoc(collection(db, COLLECTIONS.plans), {
      planCode: plan.plan_code || plan.plan_id,
      sheetName: plan.sheet_name || '',
      planTitleType: plan.plan_title_type || '',
      equipmentId,
      equipmentName: plan.equipment_name,
      operationDescription: plan.operation_description || '',
      operatingCondition: normalizeOperatingCondition(plan.operating_condition) || 'either',
      durationValue: plan.duration_value || null,
      durationUnit: plan.duration_unit || '',
      frequencyLabel: plan.frequency_label || frequencyTypeLabel(frequencyValue, frequencyUnit),
      frequencyValue,
      frequencyUnit,
      responsibleMechanical: plan.responsible_mechanical || '',
      responsibleElectrical: plan.responsible_electrical || '',
      sourceFolder: plan.source_folder || '',
      equipmentFamily: plan.equipment_family || '',
      createdAt: serverTimestamp(),
    });
    planIdMap.set(plan.plan_id, ref.id);
    summary.plansCreated++;
  }

  // 3. Phases
  const phaseIdMap = new Map<string, string>();
  for (const phase of parsed.phases) {
    const planId = planIdMap.get(phase.plan_id);
    if (!planId) {
      summary.warnings.push(`Phase ${phase.phase_id}: unresolved plan_id ${phase.plan_id}`);
      continue;
    }
    const ref = await addDoc(collection(db, COLLECTIONS.phases), {
      planId,
      phaseCode: phase.phase_code || phase.phase_id,
      phaseName: phase.phase_name,
      sourceRow: phase.source_row || null,
      sourceFolder: phase.source_folder || '',
      equipmentFamily: phase.equipment_family || '',
      createdAt: serverTimestamp(),
    });
    phaseIdMap.set(phase.phase_id, ref.id);
    summary.phasesCreated++;
  }

  // 4. Subphases -> Equipment Parts
  const partIdMap = new Map<string, string>();
  const partMeta = new Map<string, { planId: string; equipmentId: string; partName: string }>();
  for (const subphase of parsed.subphases) {
    const phaseId = phaseIdMap.get(subphase.phase_id);
    if (!phaseId) {
      summary.warnings.push(`Subphase ${subphase.subphase_id}: unresolved phase_id ${subphase.phase_id}`);
      continue;
    }
    const phaseRow = parsed.phases.find((p) => p.phase_id === subphase.phase_id);
    const planSourceId = phaseRow?.plan_id;
    const planId = planSourceId ? planIdMap.get(planSourceId) : undefined;
    const planRow = parsed.plans.find((p) => p.plan_id === planSourceId);
    const equipKey = planRow ? `${planRow.equipment_name}__${planRow.equipment_family || ''}__${planRow.source_folder || ''}` : '';
    const equipmentId = equipmentKeyToId.get(equipKey);

    if (!planId || !equipmentId) {
      summary.warnings.push(`Subphase ${subphase.subphase_id}: unresolved plan/equipment`);
      continue;
    }

    const ref = await addDoc(collection(db, COLLECTIONS.parts), {
      phaseId,
      planId,
      equipmentId,
      partCode: subphase.subphase_code || subphase.subphase_id,
      partName: subphase.subphase_name,
      sourceRow: subphase.source_row || null,
      sourceFolder: subphase.source_folder || '',
      equipmentFamily: subphase.equipment_family || '',
      createdAt: serverTimestamp(),
    });
    partIdMap.set(subphase.subphase_id, ref.id);
    partMeta.set(ref.id, { planId, equipmentId, partName: subphase.subphase_name });
    summary.partsCreated++;
  }

  // 5. Inspection Tasks -> Checklist Items
  for (const task of parsed.tasks) {
    const equipmentPartId = partIdMap.get(task.subphase_id);
    if (!equipmentPartId) {
      summary.warnings.push(`Task ${task.task_id}: unresolved subphase_id ${task.subphase_id}`);
      continue;
    }
    const meta = partMeta.get(equipmentPartId);
    await addDoc(collection(db, COLLECTIONS.checklist), {
      equipmentPartId,
      planId: meta?.planId || '',
      taskSequence: task.task_sequence || 0,
      taskDescription: task.task_description,
      sourceRow: task.source_row || null,
      sourceFolder: task.source_folder || '',
      equipmentFamily: task.equipment_family || '',
      createdAt: serverTimestamp(),
    });
    summary.checklistItemsCreated++;
  }

  // 6. Recurring Inspection Activities — one per equipment part under a plan
  for (const [equipmentPartId, meta] of partMeta.entries()) {
    const planRecord = parsed.plans.find((p) => planIdMap.get(p.plan_id) === meta.planId);
    if (!planRecord) continue;

    let frequencyValue = planRecord.frequency_value;
    let frequencyUnit = normalizeFrequencyUnit(planRecord.frequency_unit);
    if (!frequencyValue) {
      const parsedLabel = parseFrequencyLabel(planRecord.frequency_label);
      frequencyValue = parsedLabel?.value || 1;
      frequencyUnit = parsedLabel?.unit || frequencyUnit;
    }

    const assignedTeam =
      planRecord.responsible_mechanical && planRecord.responsible_electrical
        ? 'shared'
        : planRecord.responsible_electrical
        ? 'electrical'
        : 'mechanical';

    await addDoc(collection(db, COLLECTIONS.activities), {
      planId: meta.planId,
      equipmentId: meta.equipmentId,
      equipmentPartId,
      activityName: `${planRecord.equipment_name} - ${meta.partName} - ${planRecord.frequency_label || frequencyTypeLabel(frequencyValue, frequencyUnit)}`,
      frequencyType: frequencyTypeLabel(frequencyValue, frequencyUnit),
      intervalValue: frequencyValue,
      frequencyUnit,
      operatingCondition: normalizeOperatingCondition(planRecord.operating_condition) || 'either',
      assignedTeam,
      estimatedDuration: planRecord.duration_value || null,
      durationUnit: planRecord.duration_unit || '',
      isActive: true,
      lastGeneratedDate: null,
      createdAt: serverTimestamp(),
    });
    summary.activitiesCreated++;
  }

  return summary;
}

// --- Recurring scheduler ---------------------------------------------------

// Generates the next task instance for each active activity that doesn't
// already have a pending (non-terminal) instance scheduled in the future.
export async function generateUpcomingTaskInstances(): Promise<number> {
  const activities = await getActivities();
  const instances = await getTaskInstances();
  const batch = writeBatch(db);
  let created = 0;
  const now = Date.now();

  for (const activity of activities) {
    if (!activity.isActive) continue;

    const pending = instances.filter(
      (i) =>
        i.activityId === activity.id &&
        i.status !== 'Completed' &&
        i.status !== 'Cancelled' &&
        new Date(i.dueDate).getTime() >= now
    );
    if (pending.length > 0) continue;

    const lastCompleted = instances
      .filter((i) => i.activityId === activity.id && i.status === 'Completed')
      .sort((a, b) => new Date(b.completedAt || b.dueDate).getTime() - new Date(a.completedAt || a.dueDate).getTime())[0];

    const baseTime = lastCompleted ? new Date(lastCompleted.completedAt || lastCompleted.dueDate).getTime() : now;
    const intervalMs = unitToMs(activity.intervalValue, activity.frequencyUnit);
    const scheduledDate = new Date(baseTime + intervalMs);
    const dueDate = new Date(scheduledDate.getTime() + 2 * 24 * 60 * 60 * 1000);

    const ref = doc(collection(db, COLLECTIONS.instances));
    batch.set(ref, {
      activityId: activity.id,
      equipmentId: activity.equipmentId,
      equipmentPartId: activity.equipmentPartId,
      scheduledDate: scheduledDate.toISOString(),
      dueDate: dueDate.toISOString(),
      status: scheduledDate.getTime() <= now ? 'Scheduled' : 'Upcoming',
      assignedTeam: activity.assignedTeam,
      priority: 'medium',
      createdAt: serverTimestamp(),
    });
    created++;
  }

  if (created > 0) await batch.commit();
  return created;
}

export async function completeTaskInstance(
  instanceId: string,
  checklistResults: InspectionTaskInstance['checklistResults'],
  completedBy?: string
) {
  await updateTaskInstance(instanceId, {
    status: 'Completed',
    checklistResults,
    completedAt: new Date().toISOString(),
    completedBy,
  });
}

export function recomputeOverdueStatus(instances: InspectionTaskInstance[]): InspectionTaskInstance[] {
  const now = Date.now();
  return instances.map((i) => {
    if ((i.status === 'Scheduled' || i.status === 'Upcoming') && new Date(i.dueDate).getTime() < now) {
      return { ...i, status: 'Overdue' as const };
    }
    return i;
  });
}

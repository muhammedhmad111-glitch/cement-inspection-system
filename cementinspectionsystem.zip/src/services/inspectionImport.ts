import * as XLSX from 'xlsx';
import {
  RawInspectionPlanRow,
  RawPhaseRow,
  RawSubphaseRow,
  RawInspectionTaskRow,
  FrequencyUnit,
  OperatingCondition,
} from '../types/inspection';

export interface ParsedWorkbook {
  plans: RawInspectionPlanRow[];
  phases: RawPhaseRow[];
  subphases: RawSubphaseRow[];
  tasks: RawInspectionTaskRow[];
}

const SHEET_ALIASES: Record<keyof ParsedWorkbook, string[]> = {
  plans: ['inspection_plans'],
  phases: ['phases'],
  subphases: ['subphases'],
  tasks: ['inspection_tasks'],
};

function findSheet(workbook: XLSX.WorkBook, aliases: string[]): string | undefined {
  return workbook.SheetNames.find((name) =>
    aliases.includes(name.trim().toLowerCase())
  );
}

export function parseWorkbookFile(file: ArrayBuffer): ParsedWorkbook {
  const workbook = XLSX.read(file, { type: 'array' });

  const plansSheet = findSheet(workbook, SHEET_ALIASES.plans);
  const phasesSheet = findSheet(workbook, SHEET_ALIASES.phases);
  const subphasesSheet = findSheet(workbook, SHEET_ALIASES.subphases);
  const tasksSheet = findSheet(workbook, SHEET_ALIASES.tasks);

  if (!plansSheet || !phasesSheet || !subphasesSheet || !tasksSheet) {
    throw new Error(
      `Workbook is missing required sheets. Expected: inspection_plans, phases, subphases, inspection_tasks. Found: ${workbook.SheetNames.join(', ')}`
    );
  }

  return {
    plans: XLSX.utils.sheet_to_json<RawInspectionPlanRow>(workbook.Sheets[plansSheet]),
    phases: XLSX.utils.sheet_to_json<RawPhaseRow>(workbook.Sheets[phasesSheet]),
    subphases: XLSX.utils.sheet_to_json<RawSubphaseRow>(workbook.Sheets[subphasesSheet]),
    tasks: XLSX.utils.sheet_to_json<RawInspectionTaskRow>(workbook.Sheets[tasksSheet]),
  };
}

// --- Frequency conversion -------------------------------------------------

export function normalizeFrequencyUnit(unit?: string): FrequencyUnit {
  const u = (unit || '').toLowerCase().trim();
  if (u.startsWith('day')) return 'day';
  if (u.startsWith('week')) return 'week';
  if (u.startsWith('month')) return 'month';
  if (u.startsWith('year') || u.startsWith('annual')) return 'year';
  return 'month';
}

export function frequencyTypeLabel(value: number, unit: FrequencyUnit): string {
  if (unit === 'week') {
    if (value === 1) return 'Weekly';
    return `Custom (every ${value} weeks)`;
  }
  if (unit === 'month') {
    if (value === 1) return 'Monthly';
    if (value === 3) return 'Quarterly';
    if (value === 6) return 'Semi-Annual';
    if (value === 12) return 'Annual';
    return `Custom (every ${value} months)`;
  }
  if (unit === 'year') {
    if (value === 1) return 'Annual';
    return `Custom (every ${value} years)`;
  }
  if (unit === 'day') {
    if (value === 1) return 'Daily';
    return `Custom (every ${value} days)`;
  }
  return `Custom (${value} ${unit})`;
}

// Parses labels like "every_1_week", "every_3_month" as a fallback when
// frequency_value/frequency_unit columns are missing.
export function parseFrequencyLabel(label?: string): { value: number; unit: FrequencyUnit } | null {
  if (!label) return null;
  const match = label.toLowerCase().match(/every_?(\d+)_?(day|week|month|year)/);
  if (!match) return null;
  return { value: parseInt(match[1], 10), unit: match[2] as FrequencyUnit };
}

export function normalizeOperatingCondition(raw?: string): OperatingCondition | undefined {
  const v = (raw || '').toLowerCase().trim();
  if (v.includes('run')) return 'running';
  if (v.includes('stop')) return 'stoppage';
  if (v) return 'either';
  return undefined;
}

export function unitToMs(value: number, unit: FrequencyUnit): number {
  const DAY = 24 * 60 * 60 * 1000;
  switch (unit) {
    case 'day': return value * DAY;
    case 'week': return value * 7 * DAY;
    case 'month': return value * 30 * DAY;
    case 'year': return value * 365 * DAY;
  }
}

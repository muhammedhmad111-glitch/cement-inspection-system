import { useEffect, useState } from 'react';
import { RefreshCw, Search, ChevronDown, ChevronUp } from 'lucide-react';
import { getParts, getPhases, getChecklistByPart } from '../../../services/inspectionService';
import { EquipmentPart, InspectionPhase, ChecklistItem } from '../../../types/inspection';

export default function AdminInspectionParts() {
  const [loading, setLoading] = useState(true);
  const [parts, setParts] = useState<EquipmentPart[]>([]);
  const [phases, setPhases] = useState<InspectionPhase[]>([]);
  const [search, setSearch] = useState('');
  const [expanded, setExpanded] = useState<string | null>(null);
  const [checklists, setChecklists] = useState<Record<string, ChecklistItem[]>>({});

  useEffect(() => {
    (async () => {
      setLoading(true);
      const [pt, ph] = await Promise.all([getParts(), getPhases()]);
      setParts(pt);
      setPhases(ph);
      setLoading(false);
    })();
  }, []);

  const toggle = async (partId: string) => {
    if (expanded === partId) {
      setExpanded(null);
      return;
    }
    setExpanded(partId);
    if (!checklists[partId]) {
      const items = await getChecklistByPart(partId);
      setChecklists((prev) => ({ ...prev, [partId]: items.sort((a, b) => a.taskSequence - b.taskSequence) }));
    }
  };

  const filtered = parts.filter((p) => p.partName.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Equipment Parts</h1>
        <p className="text-gray-500 text-sm mt-1">Parts and inspection points, grouped by parent phase.</p>
      </div>

      <div className="relative bg-white p-4 rounded-3xl border shadow-sm">
        <Search className="absolute left-8 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
        <input
          type="text"
          placeholder="Search parts..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-2xl text-sm outline-none focus:ring-2 ring-black/5 transition-all"
        />
      </div>

      {loading ? (
        <div className="py-20 text-center bg-white rounded-3xl border shadow-sm">
          <RefreshCw className="animate-spin text-gray-400 mx-auto mb-2" size={32} />
        </div>
      ) : filtered.length === 0 ? (
        <div className="py-20 text-center bg-white rounded-3xl border shadow-sm text-gray-500 font-medium">
          No equipment parts found. Import a workbook first.
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((part) => {
            const phase = phases.find((ph) => ph.id === part.phaseId);
            const isOpen = expanded === part.id;
            return (
              <div key={part.id} className="bg-white rounded-3xl border shadow-sm overflow-hidden">
                <button onClick={() => toggle(part.id)} className="w-full flex items-center justify-between p-5 text-left">
                  <div>
                    <h3 className="font-bold">{part.partName}</h3>
                    <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">{phase?.phaseName || 'Unknown phase'}</p>
                  </div>
                  {isOpen ? <ChevronUp size={18} className="text-gray-400" /> : <ChevronDown size={18} className="text-gray-400" />}
                </button>
                {isOpen && (
                  <div className="border-t p-5 bg-gray-50/50">
                    {(checklists[part.id] || []).map((item) => (
                      <div key={item.id} className="flex items-center gap-3 text-sm py-2">
                        <span className="w-6 h-6 rounded-full bg-black text-white flex items-center justify-center text-xs font-bold flex-shrink-0">{item.taskSequence}</span>
                        <span>{item.taskDescription}</span>
                      </div>
                    ))}
                    {checklists[part.id]?.length === 0 && <p className="text-sm text-gray-400">No checklist items.</p>}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

import { useEffect, useState } from 'react';
import { RefreshCw, Search } from 'lucide-react';
import { getActivities, getEquipment } from '../../../services/inspectionService';
import { InspectionActivity, Equipment } from '../../../types/inspection';
import { cn } from '../../../lib/utils';

const TEAM_COLORS: Record<string, string> = {
  mechanical: 'bg-blue-50 text-blue-700',
  electrical: 'bg-amber-50 text-amber-700',
  shared: 'bg-purple-50 text-purple-700',
};

export default function AdminInspectionActivities() {
  const [loading, setLoading] = useState(true);
  const [activities, setActivities] = useState<InspectionActivity[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    (async () => {
      setLoading(true);
      const [act, eq] = await Promise.all([getActivities(), getEquipment()]);
      setActivities(act);
      setEquipment(eq);
      setLoading(false);
    })();
  }, []);

  const filtered = activities.filter((a) => a.activityName.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Recurring Inspection Activities</h1>
        <p className="text-gray-500 text-sm mt-1">One recurring activity per equipment part, generated from imported plans.</p>
      </div>

      <div className="relative bg-white p-4 rounded-3xl border shadow-sm">
        <Search className="absolute left-8 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
        <input
          type="text"
          placeholder="Search activities..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-2xl text-sm outline-none focus:ring-2 ring-black/5 transition-all"
        />
      </div>

      {loading ? (
        <div className="py-20 text-center bg-white rounded-3xl border shadow-sm">
          <RefreshCw className="animate-spin text-gray-400 mx-auto mb-2" size={32} />
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {filtered.map((a) => {
            const eq = equipment.find((e) => e.id === a.equipmentId);
            return (
              <div key={a.id} className="bg-white p-5 rounded-3xl border shadow-sm space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <h3 className="font-bold leading-snug">{a.activityName}</h3>
                  <span className={cn('text-[10px] font-bold uppercase tracking-widest px-2 py-1 rounded-full flex-shrink-0', TEAM_COLORS[a.assignedTeam])}>
                    {a.assignedTeam}
                  </span>
                </div>
                <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-gray-500">
                  <span>{eq?.equipmentName}</span>
                  <span>{a.frequencyType}</span>
                  <span className="capitalize">{a.operatingCondition}</span>
                  {a.estimatedDuration && <span>{a.estimatedDuration} {a.durationUnit}</span>}
                </div>
              </div>
            );
          })}
          {filtered.length === 0 && (
            <div className="md:col-span-2 py-20 text-center bg-white rounded-3xl border shadow-sm text-gray-500 font-medium">
              No activities found. Import a workbook first.
            </div>
          )}
        </div>
      )}
    </div>
  );
}

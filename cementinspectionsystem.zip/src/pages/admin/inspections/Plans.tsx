import { useEffect, useState } from 'react';
import { RefreshCw, Search } from 'lucide-react';
import { getPlans } from '../../../services/inspectionService';
import { InspectionPlan } from '../../../types/inspection';

export default function AdminInspectionPlans() {
  const [loading, setLoading] = useState(true);
  const [plans, setPlans] = useState<InspectionPlan[]>([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    (async () => {
      setLoading(true);
      setPlans(await getPlans());
      setLoading(false);
    })();
  }, []);

  const filtered = plans.filter((p) =>
    p.equipmentName.toLowerCase().includes(search.toLowerCase()) ||
    p.planCode.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Inspection Plans</h1>
        <p className="text-gray-500 text-sm mt-1">Imported recurring inspection plan definitions per equipment.</p>
      </div>

      <div className="relative bg-white p-4 rounded-3xl border shadow-sm">
        <Search className="absolute left-8 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
        <input
          type="text"
          placeholder="Search by equipment or plan code..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-2xl text-sm outline-none focus:ring-2 ring-black/5 transition-all"
        />
      </div>

      {loading ? (
        <div className="py-20 text-center bg-white rounded-3xl border shadow-sm">
          <RefreshCw className="animate-spin text-gray-400 mx-auto mb-2" size={32} />
        </div>
      ) : (
        <div className="bg-white rounded-3xl border shadow-sm overflow-hidden overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-400">
              <tr>
                <th className="text-left p-4">Plan Code</th>
                <th className="text-left p-4">Equipment</th>
                <th className="text-left p-4">Frequency</th>
                <th className="text-left p-4">Condition</th>
                <th className="text-left p-4">Duration</th>
                <th className="text-left p-4">Mechanical</th>
                <th className="text-left p-4">Electrical</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {filtered.map((p) => (
                <tr key={p.id} className="hover:bg-gray-50/50">
                  <td className="p-4 font-bold">{p.planCode}</td>
                  <td className="p-4">{p.equipmentName}</td>
                  <td className="p-4">{p.frequencyLabel}</td>
                  <td className="p-4 capitalize">{p.operatingCondition}</td>
                  <td className="p-4">{p.durationValue ? `${p.durationValue} ${p.durationUnit || ''}` : '—'}</td>
                  <td className="p-4">{p.responsibleMechanical || '—'}</td>
                  <td className="p-4">{p.responsibleElectrical || '—'}</td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={7} className="p-10 text-center text-gray-400">No plans found. Import a workbook first.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

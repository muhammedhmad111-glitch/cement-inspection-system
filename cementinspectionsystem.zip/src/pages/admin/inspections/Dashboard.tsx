import { useEffect, useState } from 'react';
import { RefreshCw, ClipboardList, AlertTriangle, CheckCircle2, Clock, Cog } from 'lucide-react';
import { getEquipment, getActivities, getTaskInstances, generateUpcomingTaskInstances, recomputeOverdueStatus } from '../../../services/inspectionService';
import { Equipment, InspectionActivity, InspectionTaskInstance } from '../../../types/inspection';
import Button from '../../../components/ui/Button';
import { toast } from 'sonner';

export default function AdminInspectionDashboard() {
  const [loading, setLoading] = useState(true);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [activities, setActivities] = useState<InspectionActivity[]>([]);
  const [instances, setInstances] = useState<InspectionTaskInstance[]>([]);
  const [generating, setGenerating] = useState(false);

  const load = async () => {
    setLoading(true);
    const [eq, act, inst] = await Promise.all([getEquipment(), getActivities(), getTaskInstances()]);
    setEquipment(eq);
    setActivities(act);
    setInstances(recomputeOverdueStatus(inst));
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const handleGenerate = async () => {
    setGenerating(true);
    try {
      const count = await generateUpcomingTaskInstances();
      toast.success(`Generated ${count} new task instance(s)`);
      load();
    } catch {
      toast.error('Failed to generate task instances');
    } finally {
      setGenerating(false);
    }
  };

  const counts = {
    upcoming: instances.filter((i) => i.status === 'Upcoming' || i.status === 'Scheduled').length,
    overdue: instances.filter((i) => i.status === 'Overdue').length,
    completed: instances.filter((i) => i.status === 'Completed').length,
    inProgress: instances.filter((i) => i.status === 'In Progress').length,
  };

  const workload = activities.reduce<Record<string, number>>((acc, a) => {
    acc[a.assignedTeam] = (acc[a.assignedTeam] || 0) + 1;
    return acc;
  }, {});

  const densityByEquipment = equipment
    .map((e) => ({ name: e.equipmentName, count: activities.filter((a) => a.equipmentId === e.id).length }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  if (loading) {
    return (
      <div className="py-20 text-center bg-white rounded-3xl border shadow-sm">
        <RefreshCw className="animate-spin text-gray-400 mx-auto mb-2" size={32} />
        <p className="text-sm text-gray-500 font-bold uppercase tracking-widest">Loading Inspection Data...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Inspection Dashboard</h1>
          <p className="text-gray-500 text-sm mt-1">Equipment inspection scheduling overview.</p>
        </div>
        <Button onClick={handleGenerate} disabled={generating} className="shadow-lg shadow-black/10">
          {generating ? <RefreshCw className="mr-2 animate-spin" size={18} /> : <Clock className="mr-2" size={18} />}
          Generate Upcoming Tasks
        </Button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {[
          { label: 'Upcoming', value: counts.upcoming, icon: Clock, color: 'text-blue-600 bg-blue-50' },
          { label: 'In Progress', value: counts.inProgress, icon: Cog, color: 'text-purple-600 bg-purple-50' },
          { label: 'Overdue', value: counts.overdue, icon: AlertTriangle, color: 'text-red-600 bg-red-50' },
          { label: 'Completed', value: counts.completed, icon: CheckCircle2, color: 'text-green-600 bg-green-50' },
        ].map((stat) => (
          <div key={stat.label} className="bg-white p-6 rounded-3xl border shadow-sm">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center mb-4 ${stat.color}`}>
              <stat.icon size={20} />
            </div>
            <p className="text-3xl font-bold">{stat.value}</p>
            <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mt-1">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-3xl border shadow-sm">
          <h2 className="font-bold mb-4 flex items-center gap-2"><ClipboardList size={18} /> Workload by Team</h2>
          <div className="space-y-3">
            {Object.entries(workload).length === 0 && <p className="text-sm text-gray-400">No activities yet.</p>}
            {Object.entries(workload).map(([team, count]) => (
              <div key={team} className="flex items-center justify-between text-sm">
                <span className="capitalize font-medium">{team}</span>
                <span className="font-bold">{count}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border shadow-sm">
          <h2 className="font-bold mb-4">Highest Inspection Density</h2>
          <div className="space-y-3">
            {densityByEquipment.length === 0 && <p className="text-sm text-gray-400">No equipment yet. Run an import first.</p>}
            {densityByEquipment.map((e) => (
              <div key={e.name} className="flex items-center justify-between text-sm">
                <span className="font-medium">{e.name}</span>
                <span className="font-bold">{e.count} activities</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

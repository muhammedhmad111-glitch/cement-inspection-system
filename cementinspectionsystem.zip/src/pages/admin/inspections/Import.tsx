import { useState } from 'react';
import { UploadCloud, RefreshCw, CheckCircle2, AlertTriangle } from 'lucide-react';
import Button from '../../../components/ui/Button';
import { toast } from 'sonner';
import { parseWorkbookFile } from '../../../services/inspectionImport';
import { importWorkbook } from '../../../services/inspectionService';
import { ImportSummary } from '../../../types/inspection';

export default function AdminInspectionImport() {
  const [file, setFile] = useState<File | null>(null);
  const [importing, setImporting] = useState(false);
  const [summary, setSummary] = useState<ImportSummary | null>(null);

  const handleImport = async () => {
    if (!file) {
      toast.error('Select an Excel file first');
      return;
    }
    setImporting(true);
    setSummary(null);
    try {
      const buffer = await file.arrayBuffer();
      const parsed = parseWorkbookFile(buffer);
      const result = await importWorkbook(parsed);
      setSummary(result);
      toast.success('Import completed');
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Import failed');
    } finally {
      setImporting(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Import Inspection Data</h1>
        <p className="text-gray-500 text-sm mt-1">
          Upload <code className="bg-gray-100 px-1.5 py-0.5 rounded text-xs">all_ijps_master_database.xlsx</code> with
          sheets: inspection_plans, phases, subphases, inspection_tasks.
        </p>
      </div>

      <div className="bg-white p-8 rounded-3xl border shadow-sm space-y-6">
        <label className="flex flex-col items-center justify-center gap-3 border-2 border-dashed border-gray-200 rounded-2xl py-16 cursor-pointer hover:border-black/30 transition-colors">
          <UploadCloud size={40} className="text-gray-400" />
          <span className="text-sm font-bold text-gray-600">{file ? file.name : 'Click to select workbook (.xlsx)'}</span>
          <input
            type="file"
            accept=".xlsx,.xls"
            className="hidden"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
          />
        </label>

        <Button onClick={handleImport} disabled={!file || importing} className="w-full py-5 text-base font-bold uppercase tracking-widest">
          {importing ? <RefreshCw className="mr-2 animate-spin" size={18} /> : <UploadCloud className="mr-2" size={18} />}
          {importing ? 'Importing...' : 'Run Import'}
        </Button>
      </div>

      {summary && (
        <div className="bg-white p-8 rounded-3xl border shadow-sm space-y-6">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="text-green-600" size={22} />
            <h2 className="text-xl font-bold">Import Summary</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {[
              ['Equipment', summary.equipmentCreated],
              ['Plans', summary.plansCreated],
              ['Phases', summary.phasesCreated],
              ['Equipment Parts', summary.partsCreated],
              ['Checklist Items', summary.checklistItemsCreated],
              ['Recurring Activities', summary.activitiesCreated],
            ].map(([label, value]) => (
              <div key={label as string} className="bg-gray-50 rounded-2xl p-4 text-center">
                <p className="text-2xl font-bold">{value}</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mt-1">{label}</p>
              </div>
            ))}
          </div>
          {summary.warnings.length > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 space-y-2">
              <div className="flex items-center gap-2 text-amber-700 font-bold text-sm">
                <AlertTriangle size={16} />
                {summary.warnings.length} warning(s)
              </div>
              <ul className="text-xs text-amber-700 space-y-1 max-h-48 overflow-y-auto">
                {summary.warnings.map((w, i) => <li key={i}>• {w}</li>)}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

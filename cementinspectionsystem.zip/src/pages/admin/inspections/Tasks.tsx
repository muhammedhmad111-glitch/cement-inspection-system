import { useEffect, useState } from 'react';
import { RefreshCw, X, Save, CheckCircle2 } from 'lucide-react';
import {
  getTaskInstances,
  getActivities,
  getEquipment,
  getChecklistByPart,
  updateTaskInstance,
  completeTaskInstance,
  recomputeOverdueStatus,
} from '../../../services/inspectionService';
import { InspectionTaskInstance, InspectionActivity, Equipment, TaskInstanceStatus } from '../../../types/inspection';
import Button from '../../../components/ui/Button';
import { cn } from '../../../lib/utils';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'framer-motion';
import { format } from 'date-fns';

const STATUS_COLORS: Record<TaskInstanceStatus, string> = {
  Scheduled: 'bg-gray-100 text-gray-700',
  Upcoming: 'bg-blue-50 text-blue-700',
  'In Progress': 'bg-purple-50 text-purple-700',
  Completed: 'bg-green-50 text-green-700',
  Overdue: 'bg-red-50 text-red-700',
  Delayed: 'bg-amber-50 text-amber-700',
  Cancelled: 'bg-gray-100 text-gray-400',
};

export default function AdminInspectionTasks() {
  const [loading, setLoading] = useState(true);
  const [instances, setInstances] = useState<InspectionTaskInstance[]>([]);
  const [activities, setActivities] = useState<InspectionActivity[]>([]);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [activeInstance, setActiveInstance] = useState<InspectionTaskInstance | null>(null);
  const [checklistDraft, setChecklistDraft] = useState<InspectionTaskInstance['checklistResults']>([]);

  const load = async () => {
    setLoading(true);
    const [inst, act, eq] = await Promise.all([getTaskInstances(), getActivities(), getEquipment()]);
    setInstances(recomputeOverdueStatus(inst));
    setActivities(act);
    setEquipment(eq);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const openExecution = async (instance: InspectionTaskInstance) => {
    setActiveInstance(instance);
    if (instance.checklistResults && instance.checklistResults.length > 0) {
      setChecklistDraft(instance.checklistResults);
    } else {
      const items = await getChecklistByPart(instance.equipmentPartId);
      setChecklistDraft(
        items.sort((a, b) => a.taskSequence - b.taskSequence).map((i) => ({
          checklistItemId: i.id,
          taskDescription: i.taskDescription,
        }))
      );
    }
    await updateTaskInstance(instance.id, { status: 'In Progress' });
  };

  const handleResult = (checklistItemId: string, result: 'pass' | 'fail' | 'na') => {
    setChecklistDraft((prev) => prev?.map((c) => (c.checklistItemId === checklistItemId ? { ...c, result } : c)));
  };

  const handleComplete = async () => {
    if (!activeInstance) return;
    try {
      await completeTaskInstance(activeInstance.id, checklistDraft);
      toast.success('Inspection task completed');
      setActiveInstance(null);
      load();
    } catch {
      toast.error('Failed to complete task');
    }
  };

  const filtered = statusFilter === 'all' ? instances : instances.filter((i) => i.status === statusFilter);

  if (loading) {
    return (
      <div className="py-20 text-center bg-white rounded-3xl border shadow-sm">
        <RefreshCw className="animate-spin text-gray-400 mx-auto mb-2" size={32} />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Inspection Tasks</h1>
        <p className="text-gray-500 text-sm mt-1">Generated task instances ready for execution.</p>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {['all', 'Upcoming', 'Scheduled', 'In Progress', 'Overdue', 'Completed', 'Cancelled'].map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className={cn(
              'px-4 py-2 rounded-2xl text-xs font-bold whitespace-nowrap transition-all',
              statusFilter === s ? 'bg-black text-white' : 'bg-white border text-gray-500 hover:bg-gray-50'
            )}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="bg-white rounded-3xl border shadow-sm overflow-hidden overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 text-[10px] font-bold uppercase tracking-widest text-gray-400">
            <tr>
              <th className="text-left p-4">Equipment</th>
              <th className="text-left p-4">Scheduled</th>
              <th className="text-left p-4">Due</th>
              <th className="text-left p-4">Status</th>
              <th className="text-left p-4">Team</th>
              <th className="text-left p-4"></th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {filtered.map((inst) => {
              const activity = activities.find((a) => a.id === inst.activityId);
              const eq = equipment.find((e) => e.id === inst.equipmentId);
              return (
                <tr key={inst.id} className="hover:bg-gray-50/50">
                  <td className="p-4 font-bold">{eq?.equipmentName || activity?.activityName}</td>
                  <td className="p-4">{format(new Date(inst.scheduledDate), 'MMM d, yyyy')}</td>
                  <td className="p-4">{format(new Date(inst.dueDate), 'MMM d, yyyy')}</td>
                  <td className="p-4">
                    <span className={cn('px-2 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest', STATUS_COLORS[inst.status])}>
                      {inst.status}
                    </span>
                  </td>
                  <td className="p-4 capitalize">{inst.assignedTeam}</td>
                  <td className="p-4 text-right">
                    {inst.status !== 'Completed' && inst.status !== 'Cancelled' && (
                      <Button onClick={() => openExecution(inst)} variant="outline" className="text-xs py-2 px-4">
                        Execute
                      </Button>
                    )}
                  </td>
                </tr>
              );
            })}
            {filtered.length === 0 && (
              <tr><td colSpan={6} className="p-10 text-center text-gray-400">No task instances. Generate them from the Dashboard.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      <AnimatePresence>
        {activeInstance && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setActiveInstance(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }} animate={{ scale: 1, opacity: 1, y: 0 }} exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-white w-full max-w-lg rounded-[40px] overflow-hidden shadow-2xl flex flex-col max-h-[85vh]"
            >
              <div className="p-8 border-b flex items-center justify-between bg-gray-50/50">
                <div>
                  <h2 className="text-2xl font-bold tracking-tight">Execute Inspection</h2>
                  <p className="text-gray-500 text-xs font-bold uppercase tracking-widest mt-1">Checklist</p>
                </div>
                <button onClick={() => setActiveInstance(null)} className="p-3 hover:bg-gray-200 rounded-2xl transition-colors">
                  <X size={24} />
                </button>
              </div>
              <div className="p-8 space-y-4 overflow-y-auto flex-grow">
                {checklistDraft?.map((item) => (
                  <div key={item.checklistItemId} className="space-y-2">
                    <p className="text-sm font-medium">{item.taskDescription}</p>
                    <div className="flex gap-2">
                      {(['pass', 'fail', 'na'] as const).map((r) => (
                        <button
                          key={r}
                          onClick={() => handleResult(item.checklistItemId, r)}
                          className={cn(
                            'px-3 py-1.5 rounded-xl text-xs font-bold uppercase tracking-widest border',
                            item.result === r ? 'bg-black text-white border-black' : 'text-gray-500 border-gray-200 hover:bg-gray-50'
                          )}
                        >
                          {r}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
                {(!checklistDraft || checklistDraft.length === 0) && <p className="text-sm text-gray-400">No checklist items for this part.</p>}
              </div>
              <div className="p-8 border-t">
                <Button onClick={handleComplete} className="w-full py-5 text-base font-bold uppercase tracking-widest shadow-xl shadow-black/10">
                  <CheckCircle2 className="mr-2" size={20} />
                  Complete Inspection
                </Button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

import { useEffect, useState } from 'react';
import { RefreshCw, Search, Cog } from 'lucide-react';
import { getEquipment, getPlans, getParts } from '../../../services/inspectionService';
import { Equipment, InspectionPlan, EquipmentPart } from '../../../types/inspection';

export default function AdminInspectionEquipment() {
  const [loading, setLoading] = useState(true);
  const [equipment, setEquipment] = useState<Equipment[]>([]);
  const [plans, setPlans] = useState<InspectionPlan[]>([]);
  const [parts, setParts] = useState<EquipmentPart[]>([]);
  const [search, setSearch] = useState('');
  const [expanded, setExpanded] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      setLoading(true);
      const [eq, pl, pt] = await Promise.all([getEquipment(), getPlans(), getParts()]);
      setEquipment(eq);
      setPlans(pl);
      setParts(pt);
      setLoading(false);
    })();
  }, []);

  const filtered = equipment.filter((e) =>
    e.equipmentName.toLowerCase().includes(search.toLowerCase()) ||
    e.equipmentFamily.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Equipment</h1>
        <p className="text-gray-500 text-sm mt-1">Master equipment list built from imported inspection plans.</p>
      </div>

      <div className="relative bg-white p-4 rounded-3xl border shadow-sm">
        <Search className="absolute left-8 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
        <input
          type="text"
          placeholder="Search equipment by name or family..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full pl-12 pr-4 py-3 bg-gray-50 rounded-2xl text-sm outline-none focus:ring-2 ring-black/5 transition-all"
        />
      </div>

      {loading ? (
        <div className="py-20 text-center bg-white rounded-3xl border shadow-sm">
          <RefreshCw className="animate-spin text-gray-400 mx-auto mb-2" size={32} />
        </div>
      ) : filtered.length === 0 ? (
        <div className="py-20 text-center bg-white rounded-3xl border shadow-sm text-gray-500 font-medium">
          No equipment found. Import a workbook first.
        </div>
      ) : (
        <div className="space-y-4">
          {filtered.map((e) => {
            const equipPlans = plans.filter((p) => p.equipmentId === e.id);
            const equipParts = parts.filter((p) => p.equipmentId === e.id);
            const isOpen = expanded === e.id;
            return (
              <div key={e.id} className="bg-white rounded-3xl border shadow-sm overflow-hidden">
                <button
                  onClick={() => setExpanded(isOpen ? null : e.id)}
                  className="w-full flex items-center justify-between p-6 text-left"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-gray-100 flex items-center justify-center">
                      <Cog size={22} className="text-gray-500" />
                    </div>
                    <div>
                      <h3 className="font-bold">{e.equipmentName}</h3>
                      <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400">{e.equipmentFamily || 'Unclassified'}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-6 text-sm text-gray-500">
                    <span>{equipPlans.length} plans</span>
                    <span>{equipParts.length} parts</span>
                  </div>
                </button>
                {isOpen && (
                  <div className="border-t p-6 bg-gray-50/50 space-y-3">
                    {equipPlans.map((p) => (
                      <div key={p.id} className="bg-white p-4 rounded-2xl border flex flex-wrap items-center justify-between gap-2 text-sm">
                        <span className="font-medium">{p.planCode}</span>
                        <span className="text-gray-500">{p.frequencyLabel}</span>
                        <span className="text-gray-500 capitalize">{p.operatingCondition}</span>
                        <span className="text-gray-500">{p.responsibleMechanical || p.responsibleElectrical || '—'}</span>
                      </div>
                    ))}
                    {equipPlans.length === 0 && <p className="text-sm text-gray-400">No plans linked.</p>}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

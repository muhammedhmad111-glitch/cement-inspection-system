// Inspection Management System — types
// Mirrors the relational structure of all_ijps_master_database.xlsx:
// inspection_plans -> phases -> subphases -> inspection_tasks

export type FrequencyUnit = 'day' | 'week' | 'month' | 'year';
export type OperatingCondition = 'running' | 'stoppage' | 'either';
export type Discipline = 'mechanical' | 'electrical' | 'shared';

export type TaskInstanceStatus =
  | 'Scheduled'
  | 'Upcoming'
  | 'In Progress'
  | 'Completed'
  | 'Overdue'
  | 'Delayed'
  | 'Cancelled';

export interface Equipment {
  id: string;
  equipmentName: string;
  equipmentFamily: string;
  sourceFolder?: string;
  createdAt: string;
}

export interface InspectionPlan {
  id: string;
  planCode: string;
  sheetName?: string;
  planTitleType?: string;
  equipmentId: string;
  equipmentName: string;
  operationDescription?: string;
  operatingCondition?: OperatingCondition;
  durationValue?: number;
  durationUnit?: string;
  frequencyLabel: string;
  frequencyValue: number;
  frequencyUnit: FrequencyUnit;
  responsibleMechanical?: string;
  responsibleElectrical?: string;
  sourceFolder?: string;
  equipmentFamily?: string;
  createdAt: string;
}

export interface InspectionPhase {
  id: string;
  planId: string;
  phaseCode: string;
  phaseName: string;
  sourceRow?: number;
  sourceFolder?: string;
  equipmentFamily?: string;
  createdAt: string;
}

export interface EquipmentPart {
  id: string;
  phaseId: string;
  planId: string;
  equipmentId: string;
  partCode: string;
  partName: string;
  sourceRow?: number;
  sourceFolder?: string;
  equipmentFamily?: string;
  createdAt: string;
}

export interface ChecklistItem {
  id: string;
  equipmentPartId: string;
  planId: string;
  taskSequence: number;
  taskDescription: string;
  sourceRow?: number;
  sourceFolder?: string;
  equipmentFamily?: string;
  createdAt: string;
}

export interface InspectionActivity {
  id: string;
  planId: string;
  equipmentId: string;
  equipmentPartId: string;
  activityName: string;
  frequencyType: string; // Weekly, Monthly, Quarterly, Semi-Annual, Annual, Custom
  intervalValue: number;
  frequencyUnit: FrequencyUnit;
  operatingCondition?: OperatingCondition;
  assignedTeam: Discipline;
  estimatedDuration?: number;
  durationUnit?: string;
  isActive: boolean;
  lastGeneratedDate?: string;
  createdAt: string;
}

export interface InspectionTaskInstance {
  id: string;
  activityId: string;
  equipmentId: string;
  equipmentPartId: string;
  scheduledDate: string;
  dueDate: string;
  status: TaskInstanceStatus;
  assignedInspector?: string;
  assignedTeam?: Discipline;
  priority: 'low' | 'medium' | 'high';
  checklistResults?: {
    checklistItemId: string;
    taskDescription: string;
    result?: 'pass' | 'fail' | 'na';
    notes?: string;
  }[];
  completedAt?: string;
  completedBy?: string;
  createdAt: string;
}

// Raw row shapes as they appear in the workbook sheets
export interface RawInspectionPlanRow {
  plan_id: string;
  plan_code?: string;
  sheet_name?: string;
  plan_title_type?: string;
  equipment_name: string;
  operation_description?: string;
  operating_condition?: string;
  duration_value?: number;
  duration_unit?: string;
  frequency_label?: string;
  frequency_value?: number;
  frequency_unit?: string;
  responsible_mechanical?: string;
  responsible_electrical?: string;
  source_folder?: string;
  equipment_family?: string;
}

export interface RawPhaseRow {
  phase_id: string;
  plan_id: string;
  phase_code?: string;
  phase_name: string;
  source_row?: number;
  source_folder?: string;
  equipment_family?: string;
}

export interface RawSubphaseRow {
  subphase_id: string;
  phase_id: string;
  subphase_code?: string;
  subphase_name: string;
  source_row?: number;
  source_folder?: string;
  equipment_family?: string;
}

export interface RawInspectionTaskRow {
  task_id: string;
  subphase_id: string;
  task_sequence?: number;
  task_description: string;
  source_row?: number;
  source_folder?: string;
  equipment_family?: string;
}

export interface ImportSummary {
  equipmentCreated: number;
  plansCreated: number;
  phasesCreated: number;
  partsCreated: number;
  checklistItemsCreated: number;
  activitiesCreated: number;
  warnings: string[];
}
